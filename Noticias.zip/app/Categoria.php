<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categoria extends Model
{
    public $guarder= [];

    
    /* public function noticias(){

        return $this->hasMany(Noticia::class,'noticia_id');
    } */
}
