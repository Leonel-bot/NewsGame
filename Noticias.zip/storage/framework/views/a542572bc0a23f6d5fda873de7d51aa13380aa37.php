<?php $__env->startSection('content'); ?>
<div class="container">

  <div class="tags">
    <ul>
      <a href="/Noticia/Pc"><li>PC</li></a>
      <a href="/Noticia/PlayStation"><li>Play Station</li></a>
      <a href="/Noticia/Xbox"><li>Xbox</li></a>
      <a href="/Noticia/Nintendo"><li>Nintendo</li></a>
      <a href="/Noticia/Tecnologia"><li>Tecnologia</li></a>
      <a href="/Noticia/Reviews"><li>Reviews</li></a>
    </ul>
  </div><hr>


    <div class="relevante">
        <h3 class="fuente">
            Noticias mas relevantes
        </h3><hr style="height: 1px;background: #833471;">
    </div>

    <div id="etiqueta-destacado">
        <h4>
            Destacadas
        </h4>
    </div>
        <!-- NOTICIA MAS DESTACADA -->
        <?php $__currentLoopData = $topUno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="destacadas row">
          <div class="card text-white">
                <img class="card-img" src="<?php echo e($top1->foto); ?>" alt="Card image">
                <div class="card-img-overlay">
                  <h5 class="top card-title"><?php echo e($top1->titulo); ?></h5>
                  <p class=" top card-text"><?php echo e($top1->subtitulo); ?></p>
                  <p class="top card-text"><?php echo e($top1->created_at->diffForHumans()); ?></p>
                </div>
              </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
        <!-- <div class="destacadas row">
            <div class="card text-white">
                <img class="card-img" src="https://cdn.atomix.vg/wp-content/uploads/2019/09/athem.jpg" alt="Card image">
                <div class="card-img-overlay">
                  <h5 class="top card-title">Según una nueva filtración, BioWare y EA trabajan ya en un nuevo Mass Effect</h5>
                  <p class=" top card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <p class="top card-text">Last updated 3 mins ago</p>
                </div>
              </div>
        </div> -->
        <?php $__currentLoopData = $topDos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-group row">
            <div class="destacadas card">
                <div class="card text-white">
                    <img class="card-img" src="<?php echo e($top2->foto); ?>" alt="Card image">
                    <div class="card-img-overlay">
                      <h5 class="duoTop card-title"><?php echo e($top2->titulo); ?></h5>
                      <p class="duoTop card-text"><?php echo e($top2->subtitulo); ?></p>
                      <p class="duoTop card-text"><?php echo e($top2->created_at->diffForHumans()); ?></p>
                    </div>
                  </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $topTres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="destacadas card">
                <div class="card text-white">
                    <img class="card-img" src="<?php echo e($top3->foto); ?>" alt="Card image">
                    <div class="card-img-overlay">
                      <h5 class="duoTop card-title"><?php echo e($top3->titulo); ?></h5>
                      <p class="duoTop card-text"><?php echo e($top3->subtitulo); ?></p>
                      <p class="duoTop card-text"><?php echo e($top3->created_at->diffForHumans()); ?></p>
                    </div>
                  </div>
            </div>
        </div><hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div id="etiqueta">
        <h4>
            Redes Sociales
        </h4>
    </div>
    <div class="social">
        <ul>
            <li><a href=""><img src="iconos/facebook.png" alt=""></a> </li>
            <li><a href=""><img src="iconos/google-plus.png" alt=""></a> </li>
            <li><a href=""><img src="iconos/instagram.png" alt=""></a> </li>
            <li><a href=""><img src="iconos/twitter.png" alt=""></a> </li>
            <li><a href=""><img src="iconos/whatsapp.png" alt=""></a> </li>
            <li><a href=""><img src="iconos/youtube.png" alt=""></a> </li>
        </ul>
    </div><hr>
    <div>
        <h3 class="fuente">
            Ultimas noticias agregadas
        </h3>
    </div><hr style="height: 1px;background: #833471;">

    <div id="etiqueta">
        <h4>
            Novedad
        </h4>
    </div>

    <div class="col-12">
      <div class="card-deck row">
      <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="tarjeta" class="col-12 col-lg-4">
          <img class="card-img-top" src="<?php echo e($noticia->foto); ?>" alt="Card image cap">
          <div class="card-body">
            <a href="/Noticias/<?php echo e($noticia->id); ?>"><button id="leerMas">
              <h5 id="titulo" class="card-title"><strong><?php echo e($noticia->titulo); ?></strong></h5>
            </button></a><hr>
            <p class="card-text"><?php echo e($noticia->subtitulo); ?></p>
          </div>
          <div class="card-footer">
            <small class=""><?php echo e($noticia->created_at->diffForHumans()); ?></small> <img src="iconos/reloj.png" alt="" style="height:18px;width: 18px;margin-right: 20px;">
            <img src="iconos/comentarios.png" alt="" style="height:18px;width: 18px;"> <small class=""><?php echo e(count($noticia->comentarios)); ?> comentarios</small>
          </div>
        <div>
      </div>
    </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div> 





</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noticias\resources\views/Noticias/home.blade.php ENDPATH**/ ?>