<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="tags">
    <ul>
      <li>PC</li>
      <li>Play Station</li>
      <li>Xbox</li>
      <li>Nintendo</li>
      <li>Tecnologia</li>
      <li>Reviews</li>
    </ul>
  </div><hr>

<div class="row" >
  <img class="card-img" src="<?php echo e($noticia->foto); ?>" alt="Card image">
</div><br>

<div class="social">
  <ul>
      <li><a href=""><img src="/iconos/facebook.png" alt=""></a> </li>
      <li><a href=""><img src="/iconos/google-plus.png" alt=""></a> </li>
      <li><a href=""><img src="/iconos/instagram.png" alt=""></a> </li>
      <li><a href=""><img src="/iconos/twitter.png" alt=""></a> </li>
      <li><a href=""><img src="/iconos/whatsapp.png" alt=""></a> </li>
      <li><a href=""><img src="/iconos/youtube.png" alt=""></a> </li>
  </ul>
</div><hr>

<div class="container">
    <!-- <div class="container card text-white" >
        <img class="card-img" src="https://esports.as.com/2017/06/16/cosplay/mejor-cosplay-Horizon-Zero-Dawn_1036106391_6248_1440x600.jpg" alt="Card image">
        <div class="card-img-overlay">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">Tis content is a little bit longer.</p>
          <p class="card-text">Last updated 3 mins ago</p>
        </div>
    </div> -->
      <div class="noticia container">
        <div class="titulo">
            <h1><?php echo e($noticia->titulo); ?></h1>
        </div><hr>
        <div class="subtitulo">
            <h3><?php echo e($noticia->subtitulo); ?></h3>
        </div>

        <div class="cuerpo">
          <p>
          <?php echo e($noticia->cuerpo); ?>

          </p>
        </div><hr>
      </div>

      
      <div class="admin">
        <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->id == 1): ?>
        <a href="/Editar/<?php echo e($noticia->id); ?>"><button id="editar">Editar</button></a>
        <a href="/Borrar/<?php echo e($noticia->id); ?>"><button id="borrar">Borrar</button></a>
        <?php endif; ?>
        <?php endif; ?>
      </div>


      <div class="comentario">
        <h1>Comentarios</h1>
      </div>



      <ul class="list-unstyled">
        <?php $__currentLoopData = $noticia->comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="media">   
          <div class="media-body">
            <strong><?php echo e($comentario->users->name); ?> </strong>Dijo:
           <?php echo e($comentario->coment); ?>

           <p class=""><small class="text-muted">Last updated 3 mins ago</small></p>
          </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul><hr>



      <form action="/Noticias/<?php echo e($noticia->id); ?>/Comentar" method="post"enctype="multipart/form-data"><?php echo e(csrf_field()); ?> 
      <div class="form-group">
          <label for=""><h4>Deja aqui un comentario</h4></label>
          <input type="text" name="coment" class="form-control" id="exampleFormControlInput1" placeholder="">
          <input type="hidden" name="noticia_id" value="<?php echo e($noticia->id); ?>">
          <input type="hidden" name="user_name" value="<?php echo e(User::class); ?>">
        </div>
        <input class="boton" type="submit" value="COMENTAR">
      </form>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noticias\resources\views/Noticias/detalle.blade.php ENDPATH**/ ?>