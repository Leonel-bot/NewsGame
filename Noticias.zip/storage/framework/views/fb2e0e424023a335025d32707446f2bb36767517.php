<?php $__env->startSection('content'); ?>
 
<div class="container">
    <div class="contacto">
        <h1>Contacto</h1>
    </div>
    <div class="">
        <form action="" method="post" class="formContacto">
            <div class="form-group">
                <label for="">Ingrese su nombre</label>
                <input type="text" class="form-control" id="nombreContacto" placeholder="" name="nombreContacto">
              </div>
            <div class="form-group">
                <label for="">Correo electronico</label>
                <input type="email" class="form-control" id="emailContacto" placeholder="" name="emailContacto">
              </div>
              <div class="form-group">
                <label for="">Example textarea</label>
                <textarea class="form-control" id="mensajeContacto" rows="3" name="mensajeContacto"></textarea>
              </div>
              <!-- <div class="container"> -->
                <input class="boton" type="submit" value="Enviar">
              <!-- </div> -->
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noticias\resources\views/Noticias/contacto.blade.php ENDPATH**/ ?>